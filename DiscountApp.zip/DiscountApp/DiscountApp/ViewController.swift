//
//  ViewController.swift
//  DiscountApp
//
//  Created by Yalla,Nagamani on 2/15/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var EntAmt: UITextField!
    

    @IBOutlet weak var EntDis: UITextField!
    
    
    @IBOutlet weak var Submit: UIButton!
    
    @IBOutlet var Label: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func SubmitButton(_ sender: UIButton) {
        var EnteredAmt = Double(amount.text!)
        var EnteredDiscount = Double(discount.text!)
        var priceafterdiscount = EnteredAmt! * (1-EnteredDiscount / 100)
        
        display.text="Price after discount is :"\priceafterdiscount
        
        
        
    }
    
}

