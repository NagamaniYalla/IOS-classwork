//
//  ViewController.swift
//  course display app
//
//  Created by Yalla,Nagamani on 2/10/22.
//

import UIKit

class ViewController: UIViewController {
    

    @IBOutlet weak var nextbuttn: UIButton!
    @IBOutlet weak var prevbutton: UIButton!
    @IBOutlet weak var CourseSemester: UILabel!
    @IBOutlet weak var CourseTitle: UILabel!
    @IBOutlet weak var CourseNum: UILabel!
    @IBOutlet weak var ImageDisplay: UIImageView!
    
    let courses = [["img01","44555","Network security","Fall 2022"],
    ["img02","44643","iOS","Spring 2022"],
    ["img03","44656","Streaming Data","Summer 2022"]
    ]
    var imageNumber = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //should load the details(image ,num,title and sem) of the first course (0th element)
        //previous button is disabled
        updateUI(imageNumber);
        prevbutton.isEnabled = false;
        
    }

    @IBAction func previousaction(_ sender: UIButton) {
        //next button should be enabled
        nextbuttn.isEnabled = true
        //update the UI
        imageNumber -= 1
        updateUI(imageNumber)
        //if the course position is at the 0th postion ,previous button should be disabled
        if (imageNumber == 0){
            prevbutton.isEnabled = false
        }
        
    }
    
    @IBAction func Nextaction(_ sender: UIButton) {
        //UI should be updated with the next course details
        //previous button should be enabled
        //once reaching the end of the array courses the next button should be disabled
        imageNumber += 1
        updateUI(imageNumber)
        //previous button should be enabled
        prevbutton.isEnabled = true
        //once reaching the end if of courses array,nextbutton should be disabled
        if (imageNumber == courses.count-1){
            nextbuttn.isEnabled = false
        }
    }
    
    func updateUI(_ imageNumber :Int){
        ImageDisplay.image = UIImage(named: courses[imageNumber][0])
        CourseNum.text = courses[imageNumber][1]
        CourseTitle.text = courses[imageNumber][2]
        CourseSemester.text = courses[imageNumber][3]
        
    }
}

